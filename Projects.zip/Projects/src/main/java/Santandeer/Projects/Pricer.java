package Santandeer.Projects;

import java.io.FileReader;

import java.util.ArrayList;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;
import java.text.SimpleDateFormat;  
  

import com.opencsv.CSVReader;

public class Pricer {
	
	//106	EUR/USD	1.1	1.2	01/06/2020	12:01:01:001
	
	private int SEQ_INDEX =0;
	private int CUR_INDEX=1;
	private int BID_INDEX=2;
	private int ASK_INDEX =3;
	private int DATE_INDEX =4;
	private int TIME_index =5;
	
	public double curBidMargin;
	public double curAskMargin;
	
	private List<String[]> data;
	private List<String[]> marginData; 
	private CSVReader csvReader ;
	
	public Pricer(){
	}
	
	
	
	
	
	
	/////////////////////////////////////////////////////
	/// Load the file that contains the pricing info
	//////////////////////////////////////////////////
    public void Start(String priceInfo) 
    {

    	  try
    	  {
    		 
    		  
    		csvReader=  new CSVReader(  new FileReader( priceInfo  ) );
  
    	    data = csvReader.readAll();
    	    marginData =  data;
    	   } catch (Exception e) { 
    	   }
     }
    
    
    ///////////////////////////////////////////////////
    /// Returns data with margins
   ///////////////////////////////////////////////////
    public List<String[]> GetMarginData()
    {
    	return marginData;
    }
    
	///////////////////////////////////////////////////
	/// Returns original data 
	///////////////////////////////////////////////////
	public List<String[]> GetOriginalData()
	{
	  return data;
	}
	
	/////////////////////////////////////////////////////
	/// Get sequences of pricing  
	//////////////////////////////////////////////////
	public List<Integer> GetPricingSequences() 
	{
		List<Integer> sequences = new ArrayList<Integer>();
		try
			{
					data.forEach((line) -> {
						sequences.add( Integer.parseInt( line[SEQ_INDEX]));
			        });
	
				} catch (Exception e) { }
				
		return sequences;
	}
    

	/////////////////////////////////////////////////////
	/// Get timing of pricing per ccy1/ccy2 pair
	//////////////////////////////////////////////////
	public Hashtable<String, List<Date>>  GetPricingTime() 
		{
			List<Date> time = null;
		
			// creating a currency  Dictionary
			Hashtable<String, List<Date>> ccyPair = new Hashtable<String, List<Date>>();
			
			try{
				  
				for (int i = 0; i < data.size(); i++) { 
				
					 String [] line = data.get(i);
					 
					 // currency
						 String currency= line[CUR_INDEX] ;
					 
					// time
					String sDate1=  line[DATE_INDEX] ;
					String sTime = " " + line[TIME_index];  
					sDate1 =  sDate1.replace("/", "-")  + sTime;
				    	    
				    try{
				    	Date formattedDate  =new SimpleDateFormat("dd-MM-yyyy HH:mm:ss.SSS").parse(sDate1);
				  
				    	if (! ccyPair.containsKey(currency)) {
				    		
				    		time = new ArrayList<Date>();
				    		time.add(formattedDate);
				    		ccyPair.put(currency, time);
				    	} else {
				    		
				    		 time= ccyPair.get(currency);
				    		 time.add(formattedDate);	
				    	}
				    	
				    } catch (Exception e) { 
				    	System.out.println(e.getStackTrace());
				    }
				}
			} catch (Exception e) { }
			
			return ccyPair;
		}
    
    

	/////////////////////////////////////////////////////
	/// Apply Margin to all prices
	//////////////////////////////////////////////////
	public void ApplyMarginToAllPrices(double inBid, double inAsk) 
	{
		
		 curBidMargin = inBid;
		 curAskMargin = inAsk;
		List<String[]> newData = new ArrayList<String[]>();
		try
			{
			marginData.forEach((line) -> {

				double bid = Integer.parseInt( line[BID_INDEX]);
				double ask = Integer.parseInt( line[ASK_INDEX]);
			
				bid =inBid +bid;
				ask =ask +inAsk;
				
				line[BID_INDEX] = String.valueOf(bid);
				line[BID_INDEX] = String.valueOf(ask);
						
				newData.add(line);
			  });
	
		} catch (Exception e) { }
				
		marginData =newData;
	}
	
	
	/////////////////////////////////////////////////////
	/// Apply Margin to all prices
	//////////////////////////////////////////////////
	public void ApplyMarginToSinglePrices(String currency, double inBid, double inAsk) 
	{
		 curBidMargin = inBid;
		 curAskMargin = inAsk;

		List<String[]> newData = new ArrayList<String[]>();
		try
			{
			marginData.forEach((line) -> {
						
				
				if (line[CUR_INDEX] == currency) {
						double bid = Integer.parseInt( line[BID_INDEX]);
						double ask = Integer.parseInt( line[ASK_INDEX]);
					
						bid =inBid +bid;
						ask =ask +inAsk;
						
						line[BID_INDEX] = String.valueOf(bid);
						line[BID_INDEX] = String.valueOf(ask);
						
				}
				
				newData.add(line);
			 });
	
		} catch (Exception e) { }
				
		marginData =newData;
	}
 }

