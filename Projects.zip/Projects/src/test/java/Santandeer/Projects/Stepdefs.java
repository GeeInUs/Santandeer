package Santandeer.Projects;


import io.cucumber.java.en.Given;

import static org.junit.Assert.*;

import java.nio.file.Path;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;
import java.util.Map.Entry;



public class Stepdefs {
   
	private Pricer pricer = new Pricer();
	
	@Given("I start the {string} Pricer")
    public void I_have_started_the_pricer(String pricingData)   {
		try
		{
		  pricer.Start(Path.of("").toAbsolutePath().toString() + "\\src\\test\\resources\\Santandeer\\Data\\" + pricingData); 
		}catch (Exception e) {
			
		}
    }
	
	// line sequencing check
	@Given("Each each pricing information is sequenced {string}")
    public void I_validate_pricing_sequence(String inSequence)   {
		
	   Boolean expectedSequence = Boolean.parseBoolean(inSequence);
	   Boolean actualSequence = true;
		try
		{
			List<Integer> sequenceData= pricer.GetPricingSequences();
			int first =sequenceData.get(0);
			first = first -1;
			
			
		    for (Integer seq : sequenceData) {
		    	first++;
		    	actualSequence = first == seq;
		    	if (!actualSequence) {
		    		break;
		    	}	
	        }
		}catch (Exception e) {	
		}	
		
		assertTrue ( expectedSequence == actualSequence);
    }
	
	// All currency check
	@Given("Each each pricing information arrives on time is {string}")
    public void I_validate_all_pricing_time(String inTime)   {
		
	   Boolean expectedResult = Boolean.parseBoolean(inTime);
	
	   Boolean overallResult = true;
		try
		{
			Hashtable<String, List<Date>> sequenceData= pricer.GetPricingTime();
	
			for (Entry<String, List<Date> > entry : sequenceData.entrySet()) {
			  
				
			    List<Date> timing = entry.getValue();
			    
			   Date last =  timing.get(0);
			   
			    // check timing per currency
			    for (int index = 1; index < timing.size(); index++) {
			    	
			    	 Date current =  timing.get(index);
			    	 
			    	 if (! (current.after(last) ||  current.equals(last) ) ) {
			    		 overallResult =  false;
			    		 break;	 
			        }
			    	 
			  	  current = last;
			}  
		  }
		}catch (Exception e) {
			System.out.println(e.getStackTrace());
		}
		
		assertTrue ( expectedResult == overallResult);
	}
	
	// single currency check
	@Given("A {string} pricing information arrives on time is {string}")
    public void I_validate_single_pricing_time(String inCurrency, String inTime)   {
		
	   Boolean expectedResult = Boolean.parseBoolean(inTime);
	   Boolean actualResult = true;
		try
		{
			   Hashtable<String, List<Date>> sequenceData= pricer.GetPricingTime();
			    
			    List<Date> timing = sequenceData.get(inCurrency);
			    
			   Date last =  timing.get(0);
			   Date current ;
			    // check timing per currency
			   actualResult = true;
			    for (int index = 0; index < timing.size(); index++) {
			    	
			    	  current =  timing.get(index);
			    	 
			    	 if (! (current.after(last) ||  current.equals(last) ) ) {
			    		 actualResult= false;
			    		 break;
			    }
			    last = current;
			    	 
			    }
			    // validation single currency 
			     assertTrue ( expectedResult == actualResult);
		  
		   }catch (Exception e) {}
	   }

	// apply margins to all ccy1/ccy2
	@Given("I apply {string} and {string} to all prices")
	 public void I_apply_margins_to_all_pricing(String inBid, String inAsk)  {
			
		    Double bidMargin = Double.parseDouble(inBid);
		    Double offerMargin = Double.parseDouble(inAsk);
		    
		    pricer.ApplyMarginToAllPrices(bidMargin, offerMargin);
	}
	
	
	// Apply margins to all ccy1/ccy2
	@Given("I apply {string} and {string} to {string}")
	 public void I_apply_margins_to_single_pricing(String inBid, String inAsk, String inCurrency )  {
			
		    Double bidMargin = Double.parseDouble(inBid);
		    Double offerMargin = Double.parseDouble(inAsk);
		    
		    pricer.ApplyMarginToSinglePrices(inCurrency, bidMargin, offerMargin);
	}

	// check margins on ccy1/ccy2
		@Given("I expect margins should be applied to {string}")
		 public void I_check_margins_to_single_pricing(String currency )  {
				
			 int BID_INDEX=2;
			 int ASK_INDEX =3;
			
			List <String[]> original = pricer.GetOriginalData();
			List <String[]> margin = pricer.GetMarginData();
			
			
			for (int i = 0; i < original.size(); i++) { 
				
				 String [] originalLine = original.get(i);
				 String [] marginLine = margin.get(i);
				 
				 // ORIGINAL
				double oBid=  Double.parseDouble( originalLine[BID_INDEX] );
				double oAask= Double.parseDouble(originalLine[ASK_INDEX]) ;
				
				 // MARGIN
				double actualBid= Double.parseDouble(marginLine[BID_INDEX]) ;
				double actualAsk= Double.parseDouble(marginLine[ASK_INDEX]) ;
				
				double expectedBid = pricer.curBidMargin + oBid;
			    double expectedAsk = pricer.curAskMargin + oAask;
				 
				assertTrue ( actualBid == expectedBid);		
				assertTrue ( actualAsk == expectedAsk);
				
			}
		}

	
	
}	

